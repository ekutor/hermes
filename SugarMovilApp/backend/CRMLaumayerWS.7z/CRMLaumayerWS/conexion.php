<?php


function makeSqlConnection()
{	//pruebas
	$con = new mysqli('localhost', 'root', '2nnIco5FXeVVz1B', 'db_app_crm');
	//produccion
	//$con = new mysqli('localhost', 'root', '2nnIco5FXeVVz1B', 'crm_laumayer_produccion');	

	return $con;
}

?>
