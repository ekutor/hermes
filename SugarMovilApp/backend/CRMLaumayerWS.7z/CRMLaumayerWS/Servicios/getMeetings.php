<?php

require 'conexion.php';


function getMeetings($userId,$fechaInicio)
{	$sql = "SELECT count(m.name) qty , DATE(m.date_start) as date , MONTH(m.date_start) as month ";
//$sql = "SELECT m.id,m.name,m.date_start,m.date_end,m.location,m.duration_hours,m.duration_minutes,m.status,m.parent_type ";
	$sql.= "FROM meetings_users mu,meetings m LEFT JOIN  meetings_cstm mc ON  m.id = mc.id_c ";
	$sql.= "WHERE (m.date_start BETWEEN STR_TO_DATE('$fechaInicio','%Y-%m-%d %H:%i:%s') AND date_add(STR_TO_DATE('$fechaInicio','%Y-%m-%d %H:%i:%s'), interval 1 MONTH) ";
	$sql.= "AND mu.accept_status != 'decline') ";
	$sql.= "AND mu.meeting_id=m.id ";
	$sql.= "AND mu.user_id='$userId' AND m.deleted=0 AND mu.deleted=0 ";
	$sql.= "GROUP BY DATE( DATE_ADD(m.date_start, INTERVAL -5 HOUR)) ";
	
	return getAdditionalInfoFromBD($sql);
}

function getMeeting($userId,$fechaInicio)
{	$sql = "SELECT m.id,m.name,m.date_start,m.date_end,m.location,m.duration_hours,m.duration_minutes,m.status,m.parent_type,";
	$sql.= "m.parent_id, m.type,m.reminder_time, mu.user_id ,m.description,mc.tipo_c, mc.compromiso_c,mc.objetivos_c ";
	$sql.= "FROM meetings_users mu,meetings m LEFT JOIN  meetings_cstm mc ON  m.id = mc.id_c ";
	$sql.= "WHERE (m.date_start BETWEEN STR_TO_DATE('$fechaInicio','%d-%m-%Y') AND date_add(STR_TO_DATE('$fechaInicio','%d-%m-%Y'), interval 1 day) ";
	$sql.= "AND mu.accept_status != 'decline') ";
	$sql.= "AND mu.meeting_id=m.id ";
	$sql.= "AND mu.user_id='$userId' AND m.deleted=0 AND mu.deleted=0 ";
    $sql.= "ORDER BY m.date_start ASC ";
	
	return getAdditionalInfoFromBD($sql);
}

function getOneMeeting($meetId)
{	$sql = "SELECT m.id,m.name,m.date_start,m.date_end,m.location,m.duration_hours,m.duration_minutes,m.status,m.parent_type,";
	$sql.= "m.parent_id, m.type,m.reminder_time, mu.user_id, m.description,mc.tipo_c, mc.compromiso_c,mc.objetivos_c ";
	$sql.= "FROM meetings_users mu, meetings m LEFT JOIN  meetings_cstm mc ON  m.id = mc.id_c  ";
	$sql.= "WHERE ";
	$sql.= "m.id = '$meetId' ";
	$sql.= "AND  mu.meeting_id=m.id ";
	$sql.= "AND m.deleted=0 AND mu.deleted=0 ";
	
	return getAdditionalInfoFromBD($sql);
}

function getAdditionalInfoFromBD($sql)
{	
		//Realiza el query en la base de datos
        $mysqli = makeSqlConnection();
		
		$res = $mysqli->query($sql);

        $rows = array();
        while($r = mysqli_fetch_assoc($res))
        {
                //$obj = (object) $r;
                //$a =  (array) $obj;
                $rows[] = $r;
        }

        if( empty( $rows ) )
        {
                return '{"results" :[]}';
        }
        else
        {
                //Convierte el arreglo en json y lo retorna
                $temp = json_encode(utf8ize($rows));
                return '{"results" :'.$temp.'}';
        }
}

function utf8ize($d)
{
	if (is_array($d))
	{
		foreach ($d as $k => $v)
		{
			$d[$k] = utf8ize($v);
		}
	}
	else if (is_string ($d))
	{
		return utf8_encode($d);
	}
	return $d;
}

?>
