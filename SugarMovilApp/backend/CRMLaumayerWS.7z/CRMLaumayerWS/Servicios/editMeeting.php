<?php

require 'conexion.php';
require_once('IOManager.php');
require 'utils.php';


function editMeet($modo,$id,$asunto,$descripcion,$estado,$fechaInicio,$fechaVence,$asignado,$idRelacion,$tipoRelacion,$idUsuarioLogueado, $lugar, $compromiso,$objetivos,$tipo)            
{
	date_default_timezone_set('America/Bogota');
	$fecha = date("Y/m/d h:i:s");	
	$log = new IOManager();	
	//Realiza el query en la base de datos
	$mysqli = makeSqlConnection();
	
		$descripcion = getTabs($descripcion);
	
	//--Si es un task nuevo, lo crea------------------------------------------------------------
	if($modo == 'agregar')
	{			
		$id = md5($asunto.$fecha);	
		
		$sql5 = "INSERT INTO meetings (id,name,date_entered,created_by,	type) VALUES ('$id','$asunto','$fechaInicio','$idUsuarioLogueado', 'Sugar')";
		$res5 = $mysqli->query($sql5);
		$log->log($sql5);
		if(!$res5)
		{
			$array = array("respuesta" => "FAIL", "error" => $mysqli->error);
			return json_encode($array);
		}
		
		$sql6 = "INSERT INTO meetings_cstm (id_c) VALUES ('$id')";
		$res6 = $mysqli->query($sql6);
		
		$sql6 = "INSERT INTO meetings_users (id, meeting_id, user_id, required, accept_status , date_modified, deleted) 
		VALUES ('$id','$id', '$idUsuarioLogueado', '1', 'accept', STR_TO_DATE('$fechaInicio','%Y-%m-%d %H:%i:%s') ,'0')";
		$res6 = $mysqli->query($sql6);
		
		if(!$res6)
		{
			$array = array("respuesta" => "FAIL", "error" => $mysqli->error);
			return json_encode($array);
		}
	}	
	

	//--Edita la tabla tasks-------------------------------------------------------------------
	$sql = "UPDATE meetings SET 
	name = '$asunto',
	date_modified = STR_TO_DATE('$fecha','%Y/%m/%d %H:%i:%s'),
	modified_user_id = '$idUsuarioLogueado', 
	description = '$descripcion', 
	assigned_user_id = '$asignado',
	status = '$estado',
	parent_type = '$tipoRelacion',
	parent_id = '$idRelacion',
	
	location = '$lugar' ";
	
	if ( $fechaInicio != 'null' && !empty($fechaInicio))  
	{	
		$sql = $sql.",date_start = STR_TO_DATE('$fechaInicio','%Y-%m-%d %H:%i:%s') ";
	}
	
	if ($fechaVence != 'null' && !empty($fechaVence)) 
	{
		$sql = $sql.",date_end = STR_TO_DATE('$fechaVence','%Y-%m-%d %H:%i:%s') ";
	}
	
	$sql = $sql." WHERE id = '$id'";
	
	$res = $mysqli->query($sql);
	$log->log($sql);	
	if(!$res)
	{
		$array = array("respuesta" => "FAIL", "error" => $mysqli->error);
		return json_encode($array);
	}
	
	
	
	//--Edita la tabla CSTM ------------------------------------------------------------------------------
	$sql2 = "UPDATE meetings_cstm SET 
	compromiso_c = '$compromiso' ,
	objetivos_c = '$objetivos' , 
	tipo_c = '$tipo' ";
	
	$sql2 = $sql2."WHERE id_c = '$id'";
	$log->log($sql2);
	$res2 = $mysqli->query($sql2);
		
	if(!$res2)
	{
		$array = array("respuesta" => "FAIL", "error" => $mysqli->error);
		return json_encode($array);
	}
	
		
		
	
		
	if($res && $res2)
	{
		$array = array("respuesta" => "OK" , "id" => $id);
		$log->log("OK");
		return json_encode($array);
	}
	else
	{
		$log->log("fail");
		$array = array("respuesta" => "FAIL", "error" => $mysqli->error);
		return json_encode($array);
	}
}

?>
